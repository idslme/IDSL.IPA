utils::globalVariables(c("i", "j", "counterEIC", "logIPA"))
