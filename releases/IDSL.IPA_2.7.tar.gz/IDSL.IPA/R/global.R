utils::globalVariables(c("i", "j", ".logIPA"))
