utils::globalVariables(c("x", "i", "k", "y", "dflist", "spectraList", "mzmlfile" , "scanTable" ))
